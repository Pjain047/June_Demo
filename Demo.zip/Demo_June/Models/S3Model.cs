﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class S3Model
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int RandomCode { get; set; }
    }
}
