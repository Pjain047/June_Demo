﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.EmployeeModel
{
    public class S3Modeldata
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
