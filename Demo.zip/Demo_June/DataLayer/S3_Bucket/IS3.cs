﻿using Models.EmployeeModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.S3_Bucket
{
    public interface IS3
    {
        Task<string> PutFileInsideBucketAsync(S3Modeldata model);
    }
}
