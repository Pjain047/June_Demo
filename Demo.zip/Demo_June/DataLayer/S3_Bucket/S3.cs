﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.S3;
using Amazon.S3.Model;
using DataLayer.ExistenceCheck;
using Models;
using Models.EmployeeModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.S3_Bucket
{
    public class S3:IS3
    {
        //let assume s3 bucket we have need to add txt file that has
        //ID|Name|Email|RandomCode
        //101|Ram|ram@gmail.com|1001
        private readonly AmazonS3Client _S3client = new AmazonS3Client();
        private readonly string  MyBucket = "prashantjain24051995";
         
        public async Task<string> PutFileInsideBucketAsync(S3Modeldata model)
        {
            string Message = " ";
            Console.WriteLine("Process Started.....");
            //find s3 bucket
           
            var Response = await _S3client.ListBucketsAsync();
            var Result = Response.Buckets.Any(x => x.BucketName == MyBucket);
            if (Result == true)
            {
                string FileName;
                //we have bucket, now need  add txt file
                var NewModel=ModelGenrator(model);
                var response=FileOperation.MaketxtFile(NewModel, out FileName);
                if(response==true)
                {
                    //file file and put inside bucket
                    try
                    {
                        string Path = @"D:\AWS_Related\" + FileName;
                        bool isFileExists = File.Exists(Path);
                        if(isFileExists==true)
                        {
                            Amazon.S3.Model.PutObjectRequest Request = new Amazon.S3.Model.PutObjectRequest { BucketName = MyBucket,FilePath = Path, Key = FileName, ContentType = "text/plain" };
                            var S3Response = await _S3client.PutObjectAsync(Request, System.Threading.CancellationToken.None);
                            if (S3Response.HttpStatusCode.ToString() == "OK")
                            {
                                Message = "Added";
                                //below for just check need to add this in lambda
                                //await ReadDataAndPutIntoNewBucket();
                            }
                            else
                            {
                                Message = S3Response.ResponseMetadata.Metadata.ToString();
                            }
                        }
                        else
                        {
                            Message = "File not Exist";
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        
                    }
                }
            }
            else
            {
                Message = "Bucket Not founded Please check Bucket Exists";
            }
            return Message;
        }

        private S3Model ModelGenrator(S3Modeldata model)
        {
            Random rd = new Random();
            var code=rd.Next(1001, 9999);

            return new S3Model { Id = model.Id, Name = model.Name, Email = model.Email, RandomCode = code };
        }

        //this is for lambda 

        public  async Task ReadDataAndPutIntoNewBucket()
        {
             string Newbucketname = "prashantjain24051994archive";
             //check for new bucket if not make new bucket
            //await CreateBucketWithName.AddbucketAsync(Newbucketname); 
            var Response = await _S3client.ListObjectsAsync(MyBucket);
            if(Response.HttpStatusCode.ToString()=="OK")
            {
                foreach (var item in Response.S3Objects)
                {
                    var K = item.Key;
                    var Request = new Amazon.S3.Model.GetObjectRequest { BucketName = MyBucket, Key = K };
                    try
                    {
                        var Respo = await _S3client.GetObjectAsync(Request, System.Threading.CancellationToken.None);
                        if (Respo.HttpStatusCode.ToString() == "OK")
                        {
                            
                            //let read data from file
                            //string path = @"D:\AWS_Related\Response\"+K;
                            string path = @"D:\AWS_Related\tmp\" + K;
                            //below use to write file inside local path
                            //we can use this to move this file to other bucket
                            await Respo.WriteResponseStreamToFileAsync(path, false, System.Threading.CancellationToken.None);

                            //here will move this file to new bucket and put record inside new DB

                            //readdatafrom file
                            var Model=FileOperation.ReadFileData(path);
                            //need to add this model to DB

                            await AddDataToDBForS3(Model);

                            //and then put this file to new bucket and delete from bucket


                            Amazon.S3.Model.PutObjectRequest Req = new Amazon.S3.Model.PutObjectRequest { BucketName = Newbucketname, FilePath = path, Key = K, ContentType = "text/plain" };
                            var S3Response = await _S3client.PutObjectAsync(Req, System.Threading.CancellationToken.None);
                            if (S3Response.HttpStatusCode.ToString() == "OK")
                            {
                                Console.WriteLine("Added to new Bucket");
                                //Message = "Added";
                                //await ReadDataAndPutIntoNewBucket();
                                //delete from old one
                                var olddelete = await _S3client.DeleteObjectAsync(MyBucket, K);
                            }
                            else
                            {
                                // Message = S3Response.ResponseMetadata.Metadata.ToString();
                                Console.WriteLine(S3Response);
                            }


                        }
                        else
                        {
                            Console.WriteLine("Some error");
                        }


                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        private async Task AddDataToDBForS3(S3Model model)
        {
            AmazonDynamoDBClient client = new AmazonDynamoDBClient();
            string TableName = "RandonCodeTable";
            //await SomeCheckFor_Db.TableCreateAsync(TableName);
            //System.Threading.Thread.Sleep(1500);
            Table RandonCodeTable = Table.LoadTable(client, TableName);
            System.Threading.Thread.Sleep(1500);
            //let add the record into table
            var doc = new Document();
            doc["Id"] = model.Id;
            doc["Name"] = model.Name;
            doc["Email"] = model.Email;
            doc["Code"] = model.RandomCode;

            try
            {
                var Response = await RandonCodeTable.PutItemAsync(doc);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            
        }
    }
}
