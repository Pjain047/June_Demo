﻿using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ExistenceCheck
{
    public static class CreateBucketWithName
    {
        static readonly AmazonS3Client _s3client = new AmazonS3Client();
        private static PutBucketResponse PutBucketResult = null;
        public static async Task AddbucketAsync(string MyBucket)
        {
            var list = await ListAllS3();
            try
            {
                if (list.Contains(MyBucket))
                {
                    Console.WriteLine("Bucket Exist....");
                }
                else
                {
                    PutBucketRequest request = new PutBucketRequest();
                    request.BucketName = MyBucket;

                    PutBucketResult = await _s3client.PutBucketAsync(request);
                    if (PutBucketResult != null)
                    {
                        Console.WriteLine("Bucket Created");
                    }
                }
            }


            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }


        public static async Task<List<string>> ListAllS3()
        {
            var listbkt = await _s3client.ListBucketsAsync();

            List<string> st = new List<string>();
            foreach (var item in listbkt.Buckets)
            {
                st.Add(item.BucketName.ToString());
            }

            return st;

        }
    }
}
