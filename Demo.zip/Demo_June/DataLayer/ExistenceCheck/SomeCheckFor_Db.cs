﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Runtime.Internal.Util;
using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ExistenceCheck
{
    public static class SomeCheckFor_Db
    {
       static readonly AmazonDynamoDBClient client = new AmazonDynamoDBClient();
       static readonly  AmazonS3Client _s3client = new AmazonS3Client();
       private static readonly string MyBucket = "prashantjain24051995";

        public static async Task<bool> TableCheckAsync(string TableName)
        {
            bool status = true;
            var response = await client.ListTablesAsync();
            var Result = response.TableNames.Any(x => x.Equals(TableName));
            if (Result == false)
            {
                status = false;
            }
            return status;
        }

        public static async Task TableCreateAsync(string TableName)
        {
            //check if table is already there 
           

            var TableStatus = await TableCheckAsync(TableName);
            if (TableStatus == false)
            {
                //create table
                var req = request(TableName, "Id");
                //AmazonDynamoDBClient client = new AmazonDynamoDBClient();
                try
                {
                    var response = await client.CreateTableAsync(req);
                    System.Threading.Thread.Sleep(500);
                    if (response.HttpStatusCode.ToString() == "OK")
                    {
                        Console.WriteLine("Table Created...");
                       

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                 
                }

            }
            else
            {
                Console.WriteLine("Table Exist...");
               
            }
            
        }

        private static CreateTableRequest request(string tname, string PK)
        {
            var request = new CreateTableRequest
            {
                TableName = tname,
                AttributeDefinitions = new List<AttributeDefinition>
                {
                  new AttributeDefinition{ AttributeName=PK,AttributeType="S"}

                },
                KeySchema = new List<KeySchemaElement>
                {
                  new KeySchemaElement{ AttributeName=PK,KeyType="HASH"}
                },
                ProvisionedThroughput = new ProvisionedThroughput
                {
                    ReadCapacityUnits = 5,
                    WriteCapacityUnits = 5
                }
            };
            return request;

        }

        //s3 related

        private static PutBucketResponse PutBucketResult = null;
        public static async Task Addbucket()
        {
            var list = await ListAllS3();
            try
            {
                if (list.Contains(MyBucket))
                {
                    Console.WriteLine("Bucket Exist....");
                }
                else
                {
                    PutBucketRequest request = new PutBucketRequest();
                    request.BucketName = MyBucket;

                    PutBucketResult = await _s3client.PutBucketAsync(request);
                    if (PutBucketResult != null)
                    {
                        Console.WriteLine("Bucket Created");
                    }
                }
            }


            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        

        public static async Task<List<string>> ListAllS3()
        {
            var listbkt = await _s3client.ListBucketsAsync();

            List<string> st = new List<string>();
            foreach (var item in listbkt.Buckets)
            {
                st.Add(item.BucketName.ToString());
            }

            return st;

        }
    }
}
