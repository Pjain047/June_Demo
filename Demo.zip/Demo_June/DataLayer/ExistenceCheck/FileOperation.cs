﻿using Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ExistenceCheck
{
    public static class FileOperation
    {     
        readonly static string Date = System.DateTime.Now.ToString("MM_dd_yy_HH_mm_ss_tt");
        readonly static string filename = string.Concat("EmployeeData", Date, ".txt");
        readonly static string path = @"D:\AWS_Related\" + filename;
        public static bool MaketxtFile(S3Model mo,out string FileName)
        {
            bool Status = false;
            try
            {
                using (StreamWriter sw = File.CreateText(path))
                {
                    sw.WriteLine("Id|Name|Email|Code|");
                    sw.WriteLine($"{mo.Id}|{mo.Name}|{mo.Email}|{mo.RandomCode}");
                    Status = true;
                }
                
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            FileName = filename;
          
            return Status;
        }

        public static S3Model ReadFileData(string path)
        {
            S3Model mo = null;
            try
            {
                bool isFileExists = File.Exists(path);
                if (isFileExists == true)
                {
                    using (StreamReader rd=new StreamReader(path))
                    {
                        var res=rd.ReadToEnd();
                        string[] ar = res.Split('|');
                        S3Model model = new S3Model();
                        model.Id = ar[4];
                        model.Name = ar[5];
                        model.Email = ar[6];
                        model.RandomCode = Convert.ToInt32(ar[7]);
                        mo = model;
                    }
                }
                else
                {
                    Console.WriteLine("some error");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            return mo;
        }
    }
}
