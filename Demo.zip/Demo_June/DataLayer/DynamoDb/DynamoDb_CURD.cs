﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.Runtime.Internal.Util;
using DataLayer.ExistenceCheck;
using Models.EmployeeModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.DynamoDb
{
    public class DynamoDb_CURD : IDynamoDb_CURD
    {
        public static string Tablename = "EmployeeTable";

        private readonly static AmazonDynamoDBClient client = new AmazonDynamoDBClient();
        readonly Table EmployeeTable = Table.LoadTable(client, Tablename);

        public DynamoDb_CURD()
        {
                       
        }

        public async Task<string> AddEmployee(Employee emp)
        {
            string Result;
            var Employees = new Document();
            Employees["Id"] = emp.Id;
            Employees["Name"] = emp.Name;
            Employees["Email"] = emp.Email;
            Employees["Address"] = new List<string> {emp.Address.City, emp.Address.State,emp.Address.Country };

            // var res = SomeCheckFor_Db.TableCreateAsync(Tablename);
            
            try
            {
                var response = await EmployeeTable.PutItemAsync(Employees);

                Result = "Added";
            }
            catch (Exception ex)
            {
                Result = ex.Message;
                Console.WriteLine(Result);
            }
            return Result;
        }

        public async Task<List<Employee>> GetAllEmployee()
        {
            List<Employee> emplist = new List<Employee>();
            try
            {
                ScanFilter scanFilter = new ScanFilter();
                List<Document> documentList = new List<Document>();
                var search = EmployeeTable.Scan(scanFilter);
                do
                {

                    documentList = await search.GetNextSetAsync();
                    foreach (var document in documentList)
                    {
                        var emp = Convertor(document);
                        emplist.Add(emp);
                    }
                } while (!search.IsDone);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return emplist.OrderBy(x=>x.Id).ToList();
        }

        public async Task<Employee> GetByID(int id)
        {
            Employee emp = null;
            var list = await GetAllEmployee();
            try
            {
                var response = list.Single(x => x.Id == id.ToString());
                if(response!=null)
                {
                    emp = response;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
               
            }

            return emp;

        }

        public async Task<bool> DeleteEmployee(int id)
        {
            bool Result = false;
            Console.WriteLine("\n*** Executing DeleteBook() ***");
            // Optional configuration.
            DeleteItemOperationConfig config = new DeleteItemOperationConfig
            {
                // Return the deleted item.
                ReturnValues = ReturnValues.AllOldAttributes
            };
            try
            {
                var response = await EmployeeTable.DeleteItemAsync(id.ToString(),config);
                if (response != null)
                {
                    Result = true;
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            return Result;

        }

        public async Task<Employee> UpdateEmployee(Employee emp)
        {
            Employee NewResult = null;
            //get Employee obj with ID
            int.TryParse(emp.Id, out int ID);
            var Response = await GetByID(ID);
            if(Response!=null)
            { 
                var EmpUpdate = new Document();
                EmpUpdate["Id"] = emp.Id;
                EmpUpdate["Name"] = emp.Name;
                EmpUpdate["Email"] = emp.Email;
                EmpUpdate["Address"] = new List<string> { emp.Address.City, emp.Address.State, emp.Address.Country };

                UpdateItemOperationConfig config = new UpdateItemOperationConfig
                {
                    ReturnValues = ReturnValues.AllOldAttributes
                };
                try
                {
                    var Result = await EmployeeTable.UpdateItemAsync(EmpUpdate, emp.Id,config);
                    if(Result!=null)
                    {
                        
                        int.TryParse(emp.Id, out ID);
                        var EmpResult =await GetByID(ID);
                        NewResult = EmpResult;
                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }

            }
            else
            {
                Console.WriteLine("Something went wrong");
            }
            return NewResult;
        }

        private Employee Convertor(Document document)
        {
            Employee emp = new Employee();
            emp.Id = document["Id"];
            emp.Name = document["Name"];
            emp.Email = document["Email"];
            var ar = document["Address"].AsArrayOfPrimitive();

            emp.Address = new Address()
            {
                City = ar[2].Value.ToString(),
                State = ar[1].Value.ToString(),
                Country = ar[0].Value.ToString()
            };

            return emp;
        }
    }
}
