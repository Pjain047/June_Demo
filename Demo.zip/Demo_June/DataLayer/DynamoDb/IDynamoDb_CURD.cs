﻿using Models.EmployeeModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.DynamoDb
{
    public interface IDynamoDb_CURD
    {
        Task<string> AddEmployee(Employee emp);
        Task<List<Employee>> GetAllEmployee();
        Task<Employee> GetByID(int id);
        Task<bool> DeleteEmployee(int id);
        Task<Employee> UpdateEmployee(Employee emp);
    }
}
