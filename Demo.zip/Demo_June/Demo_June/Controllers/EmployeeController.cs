﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.DynamoDb;
using DataLayer.ExistenceCheck;
using DataLayer.S3_Bucket;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Models.EmployeeModel;

namespace Demo_June.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //private readonly ILogger _logger;
        private readonly IDynamoDb_CURD _curd;
        private readonly IS3 _S3curd;
        public EmployeeController( IDynamoDb_CURD curd,IS3 s3curd)
        {
            _curd = curd;
            _S3curd = s3curd;
        }

        [HttpGet("Index")]
        public IActionResult Index()
        {
           //_logger.Log(LogLevel.Debug, "Service started");
            return Content("Service is running...");
           
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _curd.GetAllEmployee());
            
        }

        [HttpGet("GetByID")]
        public async Task<IActionResult> GetByID([FromQuery]int id)
        {
            var response = await _curd.GetByID(id);
            if (response != null)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("ID not Founded or something went wrong..");
            }
        }

        [HttpPost("Add")]
        public async Task<IActionResult> AddEmployee([FromBody]Employee emp)
        {
           var Response=await _curd.AddEmployee(emp);
            if(Response!="Added")
            {
                return BadRequest(Response);
            }
            else
            {
                return Ok(Response);
            }
            
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var response = await _curd.DeleteEmployee(id);
            if(response!=true)
            {
                return BadRequest("Something wen wrong...");
            }
            else
            {
                return NoContent();
            }
 
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update(Employee emp)
        {
            var response=await _curd.UpdateEmployee(emp);
            if(response!=null)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
            
        }

        [HttpPost("PutItemS3")]
        public async Task<IActionResult> PutItemInS3(S3Modeldata model)
        {
            var Message = await _S3curd.PutFileInsideBucketAsync(model);
            if(Message!="Added")
            {
                return BadRequest($"Something went wrong :{Message}");

            }
            else
            {
                return Ok(Message);
            }
            
        }
    }
}
